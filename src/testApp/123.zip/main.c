#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>
#include <stdio.h>
#include <stdbool.h>

TTF_Font* menuFont;
SDL_Window* window;
SDL_Renderer* renderer;
SDL_Surface* backgroundImage;

void renderText(const char* text, int x, int y, bool selected, bool isSubmenu) {
    SDL_Color color;
    if (selected) {
        color.r = 255; // Red color
        color.g = 0;
        color.b = 0;
    } else {
        color.r = 0; // Black color
        color.g = 0;
        color.b = 0;
    }
    SDL_Surface* surface = TTF_RenderText_Solid(menuFont, text, color);
    SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);
    int texW = 0;
    int texH = 0;
    SDL_QueryTexture(texture, NULL, NULL, &texW, &texH);
    SDL_Rect dstrect = { x, y, texW, texH };
    SDL_RenderCopy(renderer, texture, NULL, &dstrect);
    SDL_DestroyTexture(texture);
    SDL_FreeSurface(surface);
}

// Function to render an image on the screen
void renderImage(const char* imagePath, int x, int y) {
    SDL_Surface* imageSurface = IMG_Load(imagePath);
    if (!imageSurface) {
        // Handle error loading image
        fprintf(stderr, "Error loading image: %s\n", IMG_GetError());
        return;
    }

    SDL_Texture* imageTexture = SDL_CreateTextureFromSurface(renderer, imageSurface);
    if (!imageTexture) {
        // Handle error creating texture from image
        fprintf(stderr, "Error creating texture: %s\n", SDL_GetError());
        SDL_FreeSurface(imageSurface);
        return;
    }

    SDL_Rect imageRect = {x, y, imageSurface->w, imageSurface->h};
    SDL_RenderCopy(renderer, imageTexture, NULL, &imageRect);

    SDL_DestroyTexture(imageTexture);
    SDL_FreeSurface(imageSurface);
}

int main(int argc, char* argv[]) {
    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        printf("SDL initialization failed: %s\n", SDL_GetError());
        return 1;
    }
    if (TTF_Init() != 0) {
        printf("SDL_ttf initialization failed: %s\n", TTF_GetError());
        SDL_Quit();
        return 1;
    }
    window = SDL_CreateWindow("Main Menu", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 800, 600, SDL_WINDOW_SHOWN);
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    menuFont = TTF_OpenFont("font.ttf", 24);
    if (!menuFont) {
        printf("Failed to load font: %s\n", TTF_GetError());
        TTF_Quit();
        SDL_DestroyRenderer(renderer);
        SDL_DestroyWindow(window);
        SDL_Quit();
        return 1;
    }

    backgroundImage = IMG_Load("background.jpg");
    if (!backgroundImage) {
        printf("Failed to load background image: %s\n", IMG_GetError());
        TTF_Quit();
        SDL_DestroyRenderer(renderer);
        SDL_DestroyWindow(window);
        SDL_Quit();
        return 1;
    }

    bool quit = false;
    SDL_Event event;
    int menuSelection = 0;  // 0 for "Roms", 1 for "Images", 2 for "Themes", 3 for "Exit"
    int submenuSelection = 0; // Submenu selection for "Roms"
	bool submenuVisible = false; // Flag to track if submenu should be visible for Roms or Images
	bool inRomsSubmenu = false; // Flag to track if currently in the Roms submenu
	while (!quit) {
    while (SDL_PollEvent(&event)) {
        if (event.type == SDL_QUIT) {
            quit = true;
        } else if (event.type == SDL_KEYDOWN) {
            if (event.key.keysym.sym == SDLK_ESCAPE) {
                quit = true;
            } else if (event.key.keysym.sym == SDLK_UP) {
                menuSelection = (menuSelection - 1 + 4) % 4;  // Wrap around to the last item
            } else if (event.key.keysym.sym == SDLK_DOWN) {
                menuSelection = (menuSelection + 1) % 4;  // Wrap around to the first item
            } else if (event.key.keysym.sym == SDLK_RETURN) {
                if (menuSelection == 3) {
                    quit = true; // Exit the application
                } else if (menuSelection == 0 && !submenuVisible) {
                    // Enter Roms submenu only if not already in the submenu
                    submenuVisible = true;
                    inRomsSubmenu = true;
                } else if (menuSelection == 0 && submenuVisible && inRomsSubmenu) {
                    // Handle Roms submenu selections
                    if (submenuSelection == 0) {
                        // Process "Dandy" selection
                    } else if (submenuSelection == 1) {
                        // Process "Sega" selection
                    } else if (submenuSelection == 2) {
                        // Return to the main menu for "BACK" selection
                        submenuVisible = false;
                        inRomsSubmenu = false;
                    }
                } else {
                    // Handle other menu item selections here
                }
            }
        } else if (event.type == SDL_KEYUP) {
            if (event.key.keysym.sym == SDLK_RETURN) {
                // Reset the submenu flag when Enter key is released
                submenuVisible = false;
            }
        }
    }

    SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
    SDL_RenderClear(renderer);

    // Render background image
    SDL_Texture* backgroundTexture = SDL_CreateTextureFromSurface(renderer, backgroundImage);
    SDL_RenderCopy(renderer, backgroundTexture, NULL, NULL);
    SDL_DestroyTexture(backgroundTexture);
	
    // Render menu items with images
    int menuX = 50; // Adjust the X position to move the menu to the left
    int menuY = 150;
	
    renderText("Main Menu", 300, 150, false, false);

    if (submenuVisible) {
        // Render submenu items for Roms or Images based on the current selection
        if (inRomsSubmenu) {
            renderImage("1.png", menuX, menuY + 50 * 0); // Adjust Y position for each item
            renderImage("2.png", menuX, menuY + 50 * 1);
            renderText("BACK", menuX, menuY + 50 * 2, submenuSelection == 2, false);
        } else {
            renderImage("1.png", menuX, menuY + 50 * 0);
            renderImage("1.png", menuX, menuY + 50 * 1);
        }
    } else {
        // Render main menu items
        if (menuSelection == 0) {
        renderImage("1.png", menuX, menuY + 50 * 0);
        }
        else if (menuSelection == 1) {
        renderImage("2.png", menuX, menuY + 50 * 0);
        }
        else if (menuSelection == 2) {
        renderImage("3.png", menuX, menuY + 50 * 0);
        }
        else {
        renderImage("4.png", menuX, menuY + 50 * 0);
        }
    }
    if (submenuVisible) {
        // Render submenu items for Roms or Images based on the current selection
        if (inRomsSubmenu) {
            renderText("Dandy", 330, 200, submenuSelection == 0, false);
            renderText("Sega", 330, 230, submenuSelection == 1, false);
            renderText("BACK", 330, 260, submenuSelection == 2, false);
        } else {
            renderText("Sega", 330, 230, submenuSelection == 0, false);
            renderText("Dandy", 330, 260, submenuSelection == 1, false);
        }
    } else {
        // Render main menu items
        renderText("Roms", 330, 200, menuSelection == 0, true);
        renderText("Images", 330, 230, menuSelection == 1, true);
        renderText("Themes", 330, 260, menuSelection == 2, true);
        renderText("Exit", 330, 290, menuSelection == 3, true);
    }
	
	SDL_RenderPresent(renderer);
}

    SDL_FreeSurface(backgroundImage);
    TTF_CloseFont(menuFont);
    TTF_Quit();
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
    return 0;
}

